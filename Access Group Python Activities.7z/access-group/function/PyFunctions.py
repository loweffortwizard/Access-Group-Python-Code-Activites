'''
	defining function for importing.
	allow progs to import the def 
'''

#def for squaring a number. 
def squareNumber(num):
    answer = num * num
    return answer

#def for multiplication of vars (not defined) num1 and num2.
def multiply(num1, num2):
    answer = num1 * num2
    return answer