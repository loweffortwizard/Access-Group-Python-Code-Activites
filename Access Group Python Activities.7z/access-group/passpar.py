'''
	example of showing passing paramaters.
'''

def add(number1, number2)
	answer = number1 + number2
	print(answer)
	
add(5, 5)